{
  'info' => {
    'api_server' => 'http://keg.kineticdata.com/kinetic',
    'api_username' => 'kinetic-task',
    'api_password' => 'abc123',
    'space_slug' => 'test'
  },
  'parameters' => {
    'username' => '',
    'password' => '',
    'email' => '',
    'displayName' => '',
    'spaceAdmin' => ''
  }
}
