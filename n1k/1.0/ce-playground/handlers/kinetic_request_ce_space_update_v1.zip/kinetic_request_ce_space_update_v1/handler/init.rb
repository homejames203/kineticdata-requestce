# Require the dependencies file to load the vendor libraries
require File.expand_path(File.join(File.dirname(__FILE__), "dependencies"))

class KineticRequestCeSpaceUpdateV1
  # Prepare for execution by building Hash objects for necessary values and
  # validating the present state.  This method sets the following instance
  # variables:
  # * @input_document - A REXML::Document object that represents the input Xml.
  # * @info_values - A Hash of info names to info values.
  # * @parameters - A Hash of parameter names to parameter values.
  #
  # This is a required method that is automatically called by the Kinetic Task
  # Engine.
  #
  # ==== Parameters
  # * +input+ - The String of Xml that was built by evaluating the node.xml
  #   handler template.
  def initialize(input)
    # Set the input document attribute
    @input_document = REXML::Document.new(input)
    
    # Retrieve all of the handler info values and store them in a hash variable named @info_values.
    @info_values = {}
    REXML::XPath.each(@input_document, "/handler/infos/info") do |item|
      @info_values[item.attributes["name"]] = item.text.to_s.strip
    end

    # Retrieve all of the handler parameters and store them in a hash variable named @parameters.
    @parameters = {}
    REXML::XPath.each(@input_document, "/handler/parameters/parameter") do |item|
      @parameters[item.attributes["name"]] = item.text.to_s.strip
    end
  end

  # The execute method gets called by the task engine when the handler's node is processed. It is
  # responsible for performing whatever action the name indicates.
  # If it returns a result, it will be in a special XML format that the task engine expects. These
  # results will then be available to subsequent tasks in the process.
  def execute
    begin
      api_username  = URI.encode(@info_values["api_username"])
      api_password  = @info_values["api_password"]
      api_server    = @info_values["api_server"]
      space_slug    = @parameters["space_slug"].empty? ? @info_values["space_slug"] : @parameters["space_slug"]

      api_route = "#{api_server}/app/api/v1/spaces/#{space_slug}?include=attributes"

      resource = RestClient::Resource.new(api_route, { :user => api_username, :password => api_password })

      # Test to see if we're updating attributes
      # If we are, get the current attributes from the space
      # Loop over the new attributes and update the current attributes (which will be passed in the PUT)
      current_attributes = nil
      if !@parameters["attributes"].empty?
        # Get the spaces current attributes
        response = resource.get({ accept: :json, content_type: :json })
        current_attributes = JSON.parse(response)['space']['attributes']
        
        # Parse the new attributes and loop over them to see if they already exist
        new_attributes = JSON.parse(@parameters["attributes"])
        new_attributes.each do |attribute|
          # If the attribute exists, replace it
          exists = current_attributes.find_index {|item| item['name'] == attribute['name']}
          exists.nil? ? current_attributes.push(attribute) : current_attributes[exists] = attribute
        end
      end

      # Building the object that will be sent to Kinetic Core
      data = {}
      data.tap do |json|
        json[:slug] = @parameters["new_space_slug"] if !@parameters["new_space_slug"].empty?
        json[:name] = @parameters["new_space_name"] if !@parameters["new_space_name"].empty?
        json[:bundlePath] = @parameters["bundle_path"] if !@parameters["bundle_path"].empty?
        json[:attributes] = current_attributes if !current_attributes.nil?
      end

      # Post to the API
      response = resource.put(data.to_json, { accept: :json, content_type: :json })

    # If the credentials are invalid
    rescue RestClient::Unauthorized
      raise StandardError, "(Unauthorized): You are not authorized."
    rescue RestClient::ResourceNotFound => error
      raise StandardError, error.response
    rescue RestClient::BadRequest => error
      raise StandardError, error.response
    end


    # Build the results to be returned by this handler
    results = <<-RESULTS
    <results/>
    RESULTS

    # Return the results String
    return results
  end

  ##############################################################################
  # General handler utility functions
  ##############################################################################

  # This is a template method that is used to escape results values (returned in
  # execute) that would cause the XML to be invalid.  This method is not
  # necessary if values do not contain character that have special meaning in
  # XML (&, ", <, and >), however it is a good practice to use it for all return
  # variable results in case the value could include one of those characters in
  # the future.  This method can be copied and reused between handlers.
  def escape(string)
    # Globally replace characters based on the ESCAPE_CHARACTERS constant
    string.to_s.gsub(/[&"><]/) { |special| ESCAPE_CHARACTERS[special] } if string
  end
  # This is a ruby constant that is used by the escape method
  ESCAPE_CHARACTERS = {'&'=>'&amp;', '>'=>'&gt;', '<'=>'&lt;', '"' => '&quot;'}
end
