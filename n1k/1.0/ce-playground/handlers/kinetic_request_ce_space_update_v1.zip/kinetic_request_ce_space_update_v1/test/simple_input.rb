{
  'info' => {
    'api_server' => 'http://test.kineticdata.com/kinetic',
    'api_username' => 'admin',
    'api_password' => '',
    'space_slug' => 'test'
  },
  'parameters' => {
    'space_slug' => 'test',
    'new_space_slug' => '',
    'new_space_name' => 'Template',
    'attributes' => '',
    'bundle_path' => ''
  }
}
