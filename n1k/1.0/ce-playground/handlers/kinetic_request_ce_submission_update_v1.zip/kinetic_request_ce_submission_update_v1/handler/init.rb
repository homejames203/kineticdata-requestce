# Require the dependencies file to load the vendor libraries
require File.expand_path(File.join(File.dirname(__FILE__), 'dependencies'))

# Require the REXML ruby library.
require 'rexml/document'

class KineticRequestCeSubmissionUpdateV1
  # Prepare for execution by building Hash objects for necessary values, and
  # validating the present state.  This method sets the following instance
  # variables:
  # * @input_document - A REXML::Document object that represents the input Xml.
  # * @parameters - A Hash of parameter names to parameter values.
  #
  # This is a required method that is automatically called by the Kinetic Task
  # Engine.
  #
  # ==== Parameters
  # * +input+ - The String of Xml that was built by evaluating the node.xml
  #   handler template.
  def initialize(input)
    # Set the input document attribute
    @input_document = REXML::Document.new(input)
    
    # Store the info values in a Hash of info names to values.
    @info_values = {}
    REXML::XPath.each(@input_document,"/handler/infos/info") do |item|
      @info_values[item.attributes["name"]] = item.text.to_s.strip
    end

    # Retrieve all of the handler parameters and store them in a hash attribute
    # named @parameters.
    @parameters = {}
    REXML::XPath.match(@input_document, "/handler/parameters/parameter").each do |item|
      # Associate the attribute name to the String value (stripping leading and
      # trailing whitespace)
      @parameters[item.attributes["name"]] = item.text.to_s.strip
    end
  end

  def execute
    begin
      space_slug = @parameters["space_slug"].empty? ? @info_values["space_slug"] : @parameters["space_slug"]
      # API Route
      api_route = @info_values["api_server"] +
                  "/" + space_slug + "/app/api/v1/submissions/" +
                  @parameters["submission_id"]

      puts "API ROUTE: #{api_route}"

      resource = RestClient::Resource.new(api_route,
                                          user: @info_values["api_username"],
                                          password: @info_values["api_password"])

      # Building the object that will be sent to Kinetic Core
      data = {}
      data.tap do |json|
        json[:currentPage] = {
                               "name" => (@parameters["current_page_name"] if !@parameters["current_page_name"].empty?),
                               "navigation" => (@parameters["current_page_navigation"] if !@parameters["current_page_navigation"].empty?)
                             }
        json[:coreState] = @parameters["state"] if !@parameters["state"].empty?
        json[:origin] = {"id" => @parameters["origin_id"]} if !@parameters["origin_id"].empty?
        json[:parent] = {"id" => @parameters["parent_id"]} if !@parameters["parent_id"].empty?
        json[:values] = @parameters["values"].empty? ? {} : JSON.parse(@parameters["values"])
      end

      puts "DATA: #{data.to_json}"

      # Post to the API
      result = resource.put(data.to_json, { accept: :json, content_type: :json })

    # If the credentials are invalid
    rescue RestClient::Unauthorized
      raise StandardError, "(Unauthorized): You are not authorized."
    rescue RestClient::ResourceNotFound => error
      raise StandardError, error.response
    rescue RestClient::BadRequest => error
      raise StandardError, error.response
    end


    # Build the results to be returned by this handler
    results = <<-RESULTS
    <results/>
    RESULTS

	# Return the results String
    return results
  end


  ##############################################################################
  # General handler utility functions
  ##############################################################################

  # This is a template method that is used to escape results values (returned in
  # execute) that would cause the XML to be invalid.  This method is not
  # necessary if values do not contain character that have special meaning in
  # XML (&, ", <, and >), however it is a good practice to use it for all return
  # variable results in case the value could include one of those characters in
  # the future.  This method can be copied and reused between handlers.
  def escape(string)
    # Globally replace characters based on the ESCAPE_CHARACTERS constant
    string.to_s.gsub(/[&"><]/) { |special| ESCAPE_CHARACTERS[special] } if string
  end
  # This is a ruby constant that is used by the escape method
  ESCAPE_CHARACTERS = {'&'=>'&amp;', '>'=>'&gt;', '<'=>'&lt;', '"' => '&quot;'}

  # This is a sample helper method that illustrates one method for retrieving
  # values from the input document.  As long as your node.xml document follows
  # a consistent format, these type of methods can be copied and reused between
  # handlers.
  def get_info_value(document, name)
    # Retrieve the XML node representing the desired info value
    info_element = REXML::XPath.first(document, "/handler/infos/info[@name='#{name}']")
    # If the desired element is nil, return nil; otherwise return the text value of the element
    info_element.nil? ? nil : info_element.text
  end
end
