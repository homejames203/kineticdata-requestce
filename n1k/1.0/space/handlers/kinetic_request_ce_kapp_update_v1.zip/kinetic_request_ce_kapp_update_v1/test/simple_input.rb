{
  'info' => {
    'api_server' => 'https://test.kineticdata.com/kinetic',
    'api_username' => 'user@kineticdata.com',
    'api_password' => 'password',
    'space_slug' => 'playground'
  },
  'parameters' => {
    'space_slug' => 'playground',
    'orig_kapp_slug' => 'test',
    'new_kapp_slug' => '',
    'new_kapp_name' => '',
    'attributes' => '',
    'bundle_path' => ''
  }
}
